// EduGamers Role-Based Platform JavaScript

// Global state
let currentUser = null;
let currentLanguage = 'English';
let currentRole = null;
let gameData = {
    score: 0,
    level: 1,
    lives: 3,
    currentSubject: '',
    currentQuestion: 0,
    questions: []
};

// Demo data from the provided JSON
const demoData = {
    students: [
        {id: 1, name: "Anisha Sharma", class: "Class 7", village: "Rampur", progress: 75, badges: 12},
        {id: 2, name: "Rajesh Kumar", class: "Class 6", village: "Sundarpur", progress: 68, badges: 9},
        {id: 3, name: "Priya Patel", class: "Class 8", village: "Greenville", progress: 82, badges: 15},
        {id: 4, name: "Arjun Singh", class: "Class 7", village: "Rampur", progress: 71, badges: 11}
    ],
    teachers: [
        {id: 1, name: "Mrs. Sunita Devi", subject: "Mathematics", school: "Rampur Primary", students: 25},
        {id: 2, name: "Mr. Rakesh Gupta", subject: "Science", school: "Sundarpur Secondary", students: 30}
    ],
    schools: [
        {name: "Rampur Primary School", students: 150, teachers: 8, solar_status: "Active", performance: 78},
        {name: "Sundarpur Secondary", students: 200, teachers: 12, solar_status: "Active", performance: 82},
        {name: "Greenville High School", students: 180, teachers: 10, solar_status: "Maintenance", performance: 75}
    ],
    regional_stats: {
        total_students: 530,
        total_schools: 3,
        total_teachers: 30,
        average_performance: 78.3,
        solar_coverage: 95,
        dropout_reduction: 42
    },
    game_subjects: [
        {
            name: "Mathematics",
            description: "Interactive math games with local context",
            levels: 5,
            activities: ["Number Games", "Geometry Puzzles", "Word Problems"]
        },
        {
            name: "Science", 
            description: "Environmental and basic science concepts",
            levels: 4,
            activities: ["Nature Exploration", "Solar Energy", "Agriculture Basics"]
        },
        {
            name: "Languages",
            description: "Local language and Hindi/English learning", 
            levels: 6,
            activities: ["Storytelling", "Vocabulary Games", "Reading Practice"]
        },
        {
            name: "Environmental Studies",
            description: "Sustainability and environmental awareness",
            levels: 3, 
            activities: ["Water Conservation", "Waste Management", "Climate Change"]
        }
    ],
    assignments: [
        {id: 1, title: "Solar Energy Quiz", subject: "Science", due_date: "2025-09-15", status: "pending"},
        {id: 2, title: "Math Problem Set 1", subject: "Mathematics", due_date: "2025-09-12", status: "completed"},
        {id: 3, title: "Hindi Story Writing", subject: "Languages", due_date: "2025-09-18", status: "pending"}
    ],
    achievements: [
        {name: "Math Master", description: "Complete 10 math games", icon: "🧮", earned: true},
        {name: "Science Explorer", description: "Learn about solar energy", icon: "🔬", earned: true}, 
        {name: "Language Champion", description: "Master 50 new words", icon: "📚", earned: false},
        {name: "Eco Warrior", description: "Complete environmental module", icon: "🌱", earned: true}
    ]
};

// Game questions
const gameQuestions = {
    'Mathematics': [
        {
            question: "What is 15 + 23?",
            options: ["38", "35", "42", "40"],
            correct: 0,
            explanation: "15 + 23 = 38"
        },
        {
            question: "A farmer has 12 mango trees. Each tree gives 8 mangoes. How many mangoes in total?",
            options: ["96", "84", "102", "88"],
            correct: 0,
            explanation: "12 × 8 = 96 mangoes"
        },
        {
            question: "If a square field has a side of 6 meters, what is its area?",
            options: ["36 sq meters", "24 sq meters", "30 sq meters", "42 sq meters"],
            correct: 0,
            explanation: "Area = side × side = 6 × 6 = 36 sq meters"
        }
    ],
    'Science': [
        {
            question: "What energy source powers our learning platform?",
            options: ["Solar Energy", "Wind Energy", "Coal", "Nuclear"],
            correct: 0,
            explanation: "Solar panels convert sunlight into electricity!"
        },
        {
            question: "Which gas do plants take from air during photosynthesis?",
            options: ["Carbon Dioxide", "Oxygen", "Nitrogen", "Hydrogen"],
            correct: 0,
            explanation: "Plants use CO₂ from air and sunlight to make food"
        }
    ],
    'Languages': [
        {
            question: "Which word means 'friend' in Hindi?",
            options: ["दोस्त (Dost)", "घर (Ghar)", "पानी (Paani)", "किताब (Kitaab)"],
            correct: 0,
            explanation: "दोस्त (Dost) means friend in Hindi"
        }
    ],
    'Environmental Studies': [
        {
            question: "What should we do to save water?",
            options: ["Turn off tap while brushing", "Keep tap running", "Use more water", "Waste water"],
            correct: 0,
            explanation: "Turning off the tap saves precious water!"
        }
    ]
};

// Language translations
const translations = {
    'English': {
        'Student': 'Student',
        'Teacher': 'Teacher', 
        'Government': 'Government',
        'Dashboard': 'Dashboard',
        'Games': 'Games',
        'Progress': 'Progress',
        'Achievements': 'Achievements',
        'Assignments': 'Assignments'
    },
    'हिंदी': {
        'Student': 'छात्र',
        'Teacher': 'शिक्षक',
        'Government': 'सरकार', 
        'Dashboard': 'डैशबोर्ड',
        'Games': 'खेल',
        'Progress': 'प्रगति',
        'Achievements': 'उपलब्धियां',
        'Assignments': 'असाइनमेंट'
    }
};

// Select role function - make sure it's available immediately
function selectRole(role) {
    currentRole = role;
    showLoginPage(role);
    console.log('Role selected:', role);
}

// Back to role selection
function backToRoleSelection() {
    showLandingPage();
    currentRole = null;
}

// Show landing page
function showLandingPage() {
    hideAllPages();
    const landingPage = document.getElementById('landingPage');
    if (landingPage) {
        landingPage.classList.remove('hidden');
    }
}

// Hide all pages
function hideAllPages() {
    const pages = ['landingPage', 'loginPage', 'mainApp'];
    pages.forEach(page => {
        const element = document.getElementById(page);
        if (element) {
            element.classList.add('hidden');
        }
    });

    const dashboards = ['studentDashboard', 'teacherDashboard', 'governmentDashboard'];
    dashboards.forEach(dashboard => {
        const element = document.getElementById(dashboard);
        if (element) {
            element.classList.add('hidden');
        }
    });
}

// Show login page
function showLoginPage(role) {
    hideAllPages();
    const loginPage = document.getElementById('loginPage');
    if (loginPage) {
        loginPage.classList.remove('hidden');
    }
    
    const loginTitle = document.getElementById('loginTitle');
    const loginSubtitle = document.getElementById('loginSubtitle');
    const demoCredentials = document.getElementById('demoCredentials');
    const schoolGroup = document.getElementById('schoolGroup');
    
    if (loginTitle && loginSubtitle && demoCredentials) {
        switch(role) {
            case 'student':
                loginTitle.textContent = 'Student Login';
                loginSubtitle.textContent = 'Enter your student credentials';
                demoCredentials.innerHTML = '<span>ID: student123, Password: demo</span>';
                if (schoolGroup) schoolGroup.style.display = 'block';
                break;
            case 'teacher':
                loginTitle.textContent = 'Teacher Login';
                loginSubtitle.textContent = 'Enter your teacher credentials';
                demoCredentials.innerHTML = '<span>ID: teacher123, Password: demo</span>';
                if (schoolGroup) schoolGroup.style.display = 'block';
                break;
            case 'government':
                loginTitle.textContent = 'Government Login';
                loginSubtitle.textContent = 'Enter your government credentials';
                demoCredentials.innerHTML = '<span>ID: gov123, Password: demo</span>';
                if (schoolGroup) schoolGroup.style.display = 'none';
                break;
        }
    }
}

// Handle login
function handleLogin(e) {
    e.preventDefault();
    
    const loginId = document.getElementById('loginId').value;
    const password = document.getElementById('loginPassword').value;
    
    // Simple demo authentication
    const validCredentials = {
        'student123': 'demo',
        'teacher123': 'demo',
        'gov123': 'demo'
    };
    
    if (validCredentials[loginId] === password) {
        // Set current user based on role
        switch(currentRole) {
            case 'student':
                currentUser = {
                    id: 1,
                    name: "Anisha Sharma",
                    role: 'student',
                    class: "Class 7",
                    village: "Rampur"
                };
                break;
            case 'teacher':
                currentUser = {
                    id: 1,
                    name: "Mrs. Sunita Devi",
                    role: 'teacher',
                    subject: "Mathematics",
                    school: "Rampur Primary"
                };
                break;
            case 'government':
                currentUser = {
                    id: 1,
                    name: "District Officer",
                    role: 'government',
                    department: "Education Ministry"
                };
                break;
        }
        
        showMainApp();
        showNotification(`Welcome ${currentUser.name}!`, 'success');
    } else {
        showNotification('Invalid credentials. Please try again.', 'error');
    }
}

// Show main app
function showMainApp() {
    hideAllPages();
    const mainApp = document.getElementById('mainApp');
    if (mainApp) {
        mainApp.classList.remove('hidden');
    }
    
    setupNavigation();
    updateUserInfo();
    showDashboard(currentRole);
}

// Setup navigation based on role
function setupNavigation() {
    const navMenu = document.getElementById('mainNavMenu');
    if (!navMenu) return;
    
    let navItems = [];
    
    switch(currentRole) {
        case 'student':
            navItems = [
                { id: 'studentGames', label: 'Games', active: true },
                { id: 'studentProgress', label: 'Progress' },
                { id: 'studentAchievements', label: 'Achievements' },
                { id: 'studentAssignments', label: 'Assignments' }
            ];
            break;
        case 'teacher':
            navItems = [
                { id: 'teacherStudents', label: 'Students', active: true },
                { id: 'teacherAssignmentsMgmt', label: 'Assignments' },
                { id: 'teacherAnalytics', label: 'Analytics' }
            ];
            break;
        case 'government':
            navItems = [
                { id: 'govAnalytics', label: 'Analytics', active: true },
                { id: 'govSchools', label: 'Schools' },
                { id: 'govImplementation', label: 'Implementation' }
            ];
            break;
    }
    
    navMenu.innerHTML = '';
    navItems.forEach(item => {
        const link = document.createElement('a');
        link.href = '#';
        link.className = `nav-link ${item.active ? 'active' : ''}`;
        link.textContent = item.label;
        link.onclick = (e) => {
            e.preventDefault();
            navigateToSection(item.id, e.target);
        };
        navMenu.appendChild(link);
    });
}

// Navigate to section
function navigateToSection(sectionId, clickedElement) {
    // Remove active class from all nav links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    // Add active class to clicked link
    if (clickedElement) {
        clickedElement.classList.add('active');
    }
    
    // Hide all dashboard sections
    document.querySelectorAll('.dashboard-section').forEach(section => {
        section.style.display = 'none';
    });
    
    // Show target section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.style.display = 'block';
    }
}

// Update user info
function updateUserInfo() {
    const userNameDisplay = document.getElementById('userNameDisplay');
    const userRoleDisplay = document.getElementById('userRoleDisplay');
    const userAvatar = document.getElementById('userAvatar');
    
    if (currentUser) {
        if (userNameDisplay) userNameDisplay.textContent = currentUser.name;
        if (userRoleDisplay) userRoleDisplay.textContent = currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1);
        
        if (userAvatar) {
            switch(currentUser.role) {
                case 'student':
                    userAvatar.textContent = '🎓';
                    break;
                case 'teacher':
                    userAvatar.textContent = '👩‍🏫';
                    break;
                case 'government':
                    userAvatar.textContent = '🏛️';
                    break;
            }
        }
    }
}

// Show dashboard based on role
function showDashboard(role) {
    const dashboards = ['studentDashboard', 'teacherDashboard', 'governmentDashboard'];
    dashboards.forEach(dashboard => {
        const element = document.getElementById(dashboard);
        if (element) {
            element.classList.add('hidden');
        }
    });
    
    switch(role) {
        case 'student':
            const studentDashboard = document.getElementById('studentDashboard');
            if (studentDashboard) {
                studentDashboard.classList.remove('hidden');
                loadStudentDashboard();
            }
            break;
        case 'teacher':
            const teacherDashboard = document.getElementById('teacherDashboard');
            if (teacherDashboard) {
                teacherDashboard.classList.remove('hidden');
                loadTeacherDashboard();
            }
            break;
        case 'government':
            const governmentDashboard = document.getElementById('governmentDashboard');
            if (governmentDashboard) {
                governmentDashboard.classList.remove('hidden');
                loadGovernmentDashboard();
            }
            break;
    }
}

// Load Student Dashboard
function loadStudentDashboard() {
    const studentName = document.getElementById('studentName');
    if (studentName && currentUser) {
        studentName.textContent = currentUser.name;
    }
    
    // Load games
    loadGames();
    
    // Load achievements
    loadAchievements();
    
    // Load assignments
    loadStudentAssignments();
    
    // Load progress chart
    setTimeout(() => {
        loadStudentProgressChart();
    }, 100);
}

// Load games for student
function loadGames() {
    const gamesGrid = document.getElementById('studentGamesGrid');
    if (!gamesGrid) return;
    
    gamesGrid.innerHTML = '';
    
    demoData.game_subjects.forEach(game => {
        const gameCard = document.createElement('div');
        gameCard.className = 'game-card';
        gameCard.onclick = () => playGame(game.name);
        
        const progressPercentage = Math.floor(Math.random() * 40) + 40; // 40-80%
        
        gameCard.innerHTML = `
            <div class="game-header">
                <div class="game-icon">${getGameIcon(game.name)}</div>
                <div class="game-level">Level 1-${game.levels}</div>
            </div>
            <h3>${game.name}</h3>
            <p>${game.description}</p>
            <div class="game-activities">
                ${game.activities.map(activity => `<span class="activity-tag">${activity}</span>`).join('')}
            </div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${progressPercentage}%;"></div>
            </div>
            <button class="btn btn--primary btn--full-width game-btn">Play Now</button>
        `;
        
        gamesGrid.appendChild(gameCard);
    });
}

// Get game icon
function getGameIcon(gameName) {
    const icons = {
        'Mathematics': '🔢',
        'Science': '🔬',
        'Languages': '📚',
        'Environmental Studies': '🌱'
    };
    return icons[gameName] || '🎮';
}

// Load achievements
function loadAchievements() {
    const achievementsGrid = document.getElementById('achievementsGrid');
    if (!achievementsGrid) return;
    
    achievementsGrid.innerHTML = '';
    
    demoData.achievements.forEach(achievement => {
        const achievementItem = document.createElement('div');
        achievementItem.className = `achievement-item ${achievement.earned ? 'earned' : 'not-earned'}`;
        
        achievementItem.innerHTML = `
            <div class="achievement-icon">${achievement.icon}</div>
            <div class="achievement-name">${achievement.name}</div>
            <div class="achievement-description">${achievement.description}</div>
        `;
        
        achievementsGrid.appendChild(achievementItem);
    });
}

// Load student assignments
function loadStudentAssignments() {
    const assignmentsList = document.getElementById('assignmentsList');
    if (!assignmentsList) return;
    
    assignmentsList.innerHTML = '';
    
    demoData.assignments.forEach(assignment => {
        const assignmentItem = document.createElement('div');
        assignmentItem.className = 'assignment-item';
        
        assignmentItem.innerHTML = `
            <div class="assignment-info">
                <h4>${assignment.title}</h4>
                <p>Subject: ${assignment.subject}</p>
            </div>
            <div class="assignment-status">
                <div class="assignment-due">Due: ${assignment.due_date}</div>
                <div class="status status--${assignment.status}">${assignment.status}</div>
            </div>
        `;
        
        assignmentsList.appendChild(assignmentItem);
    });
}

// Load student progress chart
function loadStudentProgressChart() {
    const ctx = document.getElementById('studentProgressChart');
    if (!ctx) return;
    
    try {
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Mathematics', 'Science', 'Languages', 'Environmental Studies'],
                datasets: [{
                    data: [75, 68, 82, 71],
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#5D878F'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    } catch (error) {
        console.log('Chart.js not available');
    }
}

// Load Teacher Dashboard
function loadTeacherDashboard() {
    loadStudentsTable();
    loadTeacherAssignments();
    setTimeout(() => {
        loadTeacherAnalyticsChart();
    }, 100);
}

// Load students table
function loadStudentsTable() {
    const studentsTableBody = document.getElementById('studentsTableBody');
    if (!studentsTableBody) return;
    
    studentsTableBody.innerHTML = '';
    
    demoData.students.forEach(student => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>${student.name}</td>
            <td>${student.class}</td>
            <td>${student.village}</td>
            <td>
                <div class="student-progress-bar">
                    <div class="student-progress-fill" style="width: ${student.progress}%;"></div>
                </div>
                ${student.progress}%
            </td>
            <td>${student.badges}</td>
            <td>
                <button class="action-btn" onclick="viewStudentDetails(${student.id})">View</button>
            </td>
        `;
        
        studentsTableBody.appendChild(row);
    });
}

// Load teacher assignments
function loadTeacherAssignments() {
    const assignmentsGrid = document.getElementById('teacherAssignmentsGrid');
    if (!assignmentsGrid) return;
    
    assignmentsGrid.innerHTML = '';
    
    demoData.assignments.forEach(assignment => {
        const assignmentCard = document.createElement('div');
        assignmentCard.className = 'assignment-card';
        
        assignmentCard.innerHTML = `
            <h4>${assignment.title}</h4>
            <div class="assignment-meta">
                <span>Subject: ${assignment.subject}</span>
                <span class="status status--${assignment.status}">${assignment.status}</span>
            </div>
            <p>Due Date: ${assignment.due_date}</p>
            <div class="assignment-actions">
                <button class="btn btn--sm btn--secondary" onclick="editAssignment(${assignment.id})">Edit</button>
                <button class="btn btn--sm btn--primary" onclick="viewSubmissions(${assignment.id})">View Submissions</button>
            </div>
        `;
        
        assignmentsGrid.appendChild(assignmentCard);
    });
}

// Load teacher analytics chart
function loadTeacherAnalyticsChart() {
    const ctx = document.getElementById('teacherAnalyticsChart');
    if (!ctx) return;
    
    try {
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                datasets: [{
                    label: 'Class Average Performance',
                    data: [75, 78, 82, 79],
                    backgroundColor: '#1FB8CD',
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    } catch (error) {
        console.log('Chart.js not available');
    }
}

// Load Government Dashboard
function loadGovernmentDashboard() {
    loadSchools();
    setTimeout(() => {
        loadGovernmentCharts();
    }, 100);
}

// Load schools for government dashboard
function loadSchools() {
    const schoolsGrid = document.getElementById('schoolsGrid');
    if (!schoolsGrid) return;
    
    schoolsGrid.innerHTML = '';
    
    demoData.schools.forEach(school => {
        const schoolCard = document.createElement('div');
        schoolCard.className = 'school-card';
        
        const statusClass = school.solar_status.toLowerCase() === 'active' ? 'active' : 'maintenance';
        
        schoolCard.innerHTML = `
            <div class="school-header">
                <h4>${school.name}</h4>
                <div class="solar-status-badge ${statusClass}">
                    ${school.solar_status}
                </div>
            </div>
            <div class="school-stats">
                <div class="school-stat">
                    <div class="school-stat-value">${school.students}</div>
                    <div class="school-stat-label">Students</div>
                </div>
                <div class="school-stat">
                    <div class="school-stat-value">${school.teachers}</div>
                    <div class="school-stat-label">Teachers</div>
                </div>
            </div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${school.performance}%;"></div>
            </div>
            <div class="progress-text">Performance: ${school.performance}%</div>
        `;
        
        schoolsGrid.appendChild(schoolCard);
    });
}

// Load government charts
function loadGovernmentCharts() {
    // Regional chart
    const regionalCtx = document.getElementById('govRegionalChart');
    if (regionalCtx) {
        try {
            new Chart(regionalCtx, {
                type: 'pie',
                data: {
                    labels: ['Rampur', 'Sundarpur', 'Greenville'],
                    datasets: [{
                        data: [150, 200, 180],
                        backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        } catch (error) {
            console.log('Chart.js not available');
        }
    }
    
    // Performance chart
    const performanceCtx = document.getElementById('govPerformanceChart');
    if (performanceCtx) {
        try {
            new Chart(performanceCtx, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                    datasets: [{
                        label: 'Average Performance',
                        data: [72, 75, 77, 78, 80, 78.3],
                        borderColor: '#1FB8CD',
                        backgroundColor: 'rgba(31, 184, 205, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100
                        }
                    }
                }
            });
        } catch (error) {
            console.log('Chart.js not available');
        }
    }
}

// Play game function
function playGame(subject) {
    gameData.currentSubject = subject;
    gameData.questions = [...(gameQuestions[subject] || [])];
    gameData.currentQuestion = 0;
    gameData.score = 0;
    gameData.level = 1;
    gameData.lives = 3;
    
    const gameTitle = document.getElementById('gameTitle');
    if (gameTitle) {
        gameTitle.textContent = `${subject} Game`;
    }
    
    const gameModal = document.getElementById('gameModal');
    if (gameModal) {
        gameModal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
    
    loadQuestion();
    updateGameStats();
    
    showNotification(`Welcome to ${subject}! Good luck!`, 'info');
}

// Load question
function loadQuestion() {
    if (gameData.currentQuestion >= gameData.questions.length) {
        endGame(true);
        return;
    }
    
    const question = gameData.questions[gameData.currentQuestion];
    const gameQuestion = document.getElementById('gameQuestion');
    const gameOptions = document.getElementById('gameOptions');
    
    if (gameQuestion) {
        gameQuestion.textContent = question.question;
    }
    
    if (gameOptions) {
        gameOptions.innerHTML = '';
        question.options.forEach((option, index) => {
            const button = document.createElement('button');
            button.className = 'option-btn';
            button.textContent = option;
            button.addEventListener('click', () => selectAnswer(index));
            gameOptions.appendChild(button);
        });
    }
}

// Select answer
function selectAnswer(selectedIndex) {
    const question = gameData.questions[gameData.currentQuestion];
    const optionButtons = document.querySelectorAll('.option-btn');
    
    optionButtons.forEach(btn => {
        btn.style.pointerEvents = 'none';
        btn.disabled = true;
    });
    
    if (selectedIndex === question.correct) {
        optionButtons[selectedIndex].classList.add('correct');
        gameData.score += 10;
        showNotification('Correct! +10 points', 'success');
        
        setTimeout(() => {
            alert(`Correct! ${question.explanation}`);
            nextQuestion();
        }, 500);
    } else {
        optionButtons[selectedIndex].classList.add('incorrect');
        optionButtons[question.correct].classList.add('correct');
        gameData.lives--;
        showNotification('Wrong answer! -1 life', 'error');
        
        setTimeout(() => {
            alert(`Wrong! ${question.explanation}`);
            
            if (gameData.lives <= 0) {
                endGame(false);
            } else {
                nextQuestion();
            }
        }, 500);
    }
    
    updateGameStats();
}

// Next question
function nextQuestion() {
    gameData.currentQuestion++;
    
    if (gameData.currentQuestion < gameData.questions.length) {
        loadQuestion();
    } else {
        endGame(true);
    }
}

// End game
function endGame(completed) {
    let message = '';
    
    if (completed) {
        message = `Congratulations! You completed ${gameData.currentSubject}!\nFinal Score: ${gameData.score}`;
        showNotification('Game completed successfully!', 'success');
    } else {
        message = `Game Over! Better luck next time.\nFinal Score: ${gameData.score}`;
        showNotification('Game over. Try again!', 'error');
    }
    
    setTimeout(() => {
        alert(message);
        closeGameModal();
    }, 500);
}

// Update game stats
function updateGameStats() {
    const scoreElement = document.getElementById('gameScore');
    const levelElement = document.getElementById('gameLevel');
    const livesElement = document.getElementById('gameLives');
    
    if (scoreElement) scoreElement.textContent = gameData.score;
    if (levelElement) levelElement.textContent = gameData.level;
    if (livesElement) livesElement.textContent = gameData.lives;
}

// Close game modal
function closeGameModal() {
    const gameModal = document.getElementById('gameModal');
    if (gameModal) {
        gameModal.classList.add('hidden');
        document.body.style.overflow = '';
    }
    
    gameData = {
        score: 0,
        level: 1,
        lives: 3,
        currentSubject: '',
        currentQuestion: 0,
        questions: []
    };
}

// Show create assignment modal
function showCreateAssignment() {
    const modal = document.getElementById('createAssignmentModal');
    if (modal) {
        modal.classList.remove('hidden');
    }
}

// Close create assignment modal
function closeCreateAssignmentModal() {
    const modal = document.getElementById('createAssignmentModal');
    if (modal) {
        modal.classList.add('hidden');
    }
    
    const form = document.getElementById('assignmentForm');
    if (form) {
        form.reset();
    }
}

// Handle create assignment
function handleCreateAssignment(e) {
    e.preventDefault();
    
    const title = document.getElementById('assignmentTitle').value;
    const subject = document.getElementById('assignmentSubject').value;
    const dueDate = document.getElementById('assignmentDueDate').value;
    const description = document.getElementById('assignmentDescription').value;
    
    const assignment = {
        id: Date.now(),
        title: title,
        subject: subject,
        due_date: dueDate,
        description: description,
        status: 'pending'
    };
    
    // Add to demo data
    demoData.assignments.push(assignment);
    
    // Reload assignments
    loadTeacherAssignments();
    
    closeCreateAssignmentModal();
    showNotification('Assignment created successfully!', 'success');
}

// Toggle user menu
function toggleUserMenu() {
    const dropdown = document.getElementById('userDropdown');
    if (dropdown) {
        dropdown.classList.toggle('hidden');
    }
}

// Show settings
function showSettings() {
    showNotification('Settings panel would open here', 'info');
    toggleUserMenu();
}

// Logout function
function logout() {
    currentUser = null;
    currentRole = null;
    showLandingPage();
    showNotification('Logged out successfully', 'success');
}

// Toggle language
function toggleLanguage() {
    currentLanguage = currentLanguage === 'English' ? 'हिंदी' : 'English';
    
    // Update all language toggles
    const langElements = ['landingCurrentLang', 'mainCurrentLang'];
    langElements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = currentLanguage;
        }
    });
    
    showNotification(`Language switched to ${currentLanguage}`, 'success');
}

// Utility functions
function viewStudentDetails(studentId) {
    const student = demoData.students.find(s => s.id === studentId);
    if (student) {
        showNotification(`Viewing details for ${student.name}`, 'info');
    }
}

function editAssignment(assignmentId) {
    showNotification('Assignment editing would open here', 'info');
}

function viewSubmissions(assignmentId) {
    showNotification('Assignment submissions would open here', 'info');
}

// Show notification
function showNotification(message, type = 'info') {
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(n => n.remove());
    
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.textContent = message;
    
    Object.assign(notification.style, {
        position: 'fixed',
        top: '100px',
        right: '20px',
        background: type === 'success' ? 'var(--color-success)' : 
                   type === 'error' ? 'var(--color-error)' : 'var(--color-info)',
        color: 'white',
        padding: '12px 20px',
        borderRadius: '6px',
        zIndex: '9999',
        transform: 'translateX(400px)',
        transition: 'transform 0.3s ease',
        maxWidth: '300px',
        wordWrap: 'break-word'
    });
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(400px)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('EduGamers Platform Initialized');
    showLandingPage();
    
    // Setup event listeners
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Landing page language toggle
    const landingLangToggle = document.getElementById('landingLangToggle');
    if (landingLangToggle) {
        landingLangToggle.addEventListener('click', toggleLanguage);
    }

    // Main app language toggle
    const mainLangToggle = document.getElementById('mainLangToggle');
    if (mainLangToggle) {
        mainLangToggle.addEventListener('click', toggleLanguage);
    }

    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Assignment form
    const assignmentForm = document.getElementById('assignmentForm');
    if (assignmentForm) {
        assignmentForm.addEventListener('submit', handleCreateAssignment);
    }

    // Modal close handlers
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            if (e.target.id === 'gameModal') {
                closeGameModal();
            } else if (e.target.id === 'createAssignmentModal') {
                closeCreateAssignmentModal();
            }
        }
    });
}

// Export functions to global scope immediately
window.selectRole = selectRole;
window.backToRoleSelection = backToRoleSelection;
window.playGame = playGame;
window.closeGameModal = closeGameModal;
window.nextQuestion = nextQuestion;
window.showCreateAssignment = showCreateAssignment;
window.closeCreateAssignmentModal = closeCreateAssignmentModal;
window.toggleUserMenu = toggleUserMenu;
window.showSettings = showSettings;
window.logout = logout;
window.viewStudentDetails = viewStudentDetails;
window.editAssignment = editAssignment;
window.viewSubmissions = viewSubmissions;